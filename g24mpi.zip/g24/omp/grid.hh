#ifndef _GRID_HH_
#define _GRID_HH_

char ***alloc_grid(long long N);
char ***gen_initial_grid(long long N, float density, int input_seed);

#endif	// _GRID_HH_
